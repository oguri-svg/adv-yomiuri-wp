import { registerBlockStyle } from "@wordpress/blocks";
import "./editor.scss";

registerBlockStyle("core/list", {
	name: "square",
	label: "四角形",
	inlineStyle: {
		listStyleType: "none",
	},
});

registerBlockStyle("core/list", {
	name: "triangle",
	label: "三角形",
	inlineStyle: {
		listStyleType: "none",
	},
});
