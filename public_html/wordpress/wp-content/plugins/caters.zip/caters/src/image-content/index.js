import { __ } from "@wordpress/i18n";
import { registerBlockType } from "@wordpress/blocks";
// import { postFeaturedImage } from "@wordpress/icons";
import metadata from "./block.json";
import Edit from "./edit";
import Save from "./save";

const { name } = metadata;
const postFeaturedImage = (
	<svg
		width="24"
		height="24"
		viewBox="0 0 200 120"
		xmlns="http://www.w3.org/2000/svg"
		aria-hidden="true"
		focusable="false"
	>
		<rect
			x="10"
			y="20"
			width="80"
			height="60"
			fill="black"
			stroke="black"
			stroke-width="2"
		></rect>
		<line
			x1="10"
			y1="100"
			x2="50"
			y2="100"
			stroke="black"
			stroke-width="8"
		></line>
		<line
			x1="10"
			y1="120"
			x2="70"
			y2="120"
			stroke="black"
			stroke-width="8"
		></line>
		<line
			x1="10"
			y1="140"
			x2="90"
			y2="140"
			stroke="black"
			stroke-width="8"
		></line>
		<rect
			x="110"
			y="20"
			width="80"
			height="60"
			fill="black"
			stroke="black"
			stroke-width="2"
		></rect>
		<line
			x1="110"
			y1="100"
			x2="150"
			y2="100"
			stroke="black"
			stroke-width="8"
		></line>
		<line
			x1="110"
			y1="120"
			x2="170"
			y2="120"
			stroke="black"
			stroke-width="8"
		></line>
		<line
			x1="110"
			y1="140"
			x2="190"
			y2="140"
			stroke="black"
			stroke-width="8"
		></line>
	</svg>
);

registerBlockType(name, {
	title: __("画像＆テキスト", "cwc-blocks"),
	icon: postFeaturedImage,
	edit: Edit,
	save: Save,
});
