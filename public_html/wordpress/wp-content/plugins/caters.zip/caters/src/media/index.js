import { __ } from "@wordpress/i18n";

import { registerBlockType } from "@wordpress/blocks";
import metadata from "./block.json";
import MediaEdit from "./edit";
import MediaSave from "./save";
import { Path, SVG } from "@wordpress/components";

const { name } = metadata;
const yticon = (
	<SVG viewBox="0 0 24 24">
		<Path d="M21.8 8s-.195-1.377-.795-1.984c-.76-.797-1.613-.8-2.004-.847-2.798-.203-6.996-.203-6.996-.203h-.01s-4.197 0-6.996.202c-.39.046-1.242.05-2.003.846C2.395 6.623 2.2 8 2.2 8S2 9.62 2 11.24v1.517c0 1.618.2 3.237.2 3.237s.195 1.378.795 1.985c.76.797 1.76.77 2.205.855 1.6.153 6.8.2 6.8.2s4.203-.005 7-.208c.392-.047 1.244-.05 2.005-.847.6-.607.795-1.985.795-1.985s.2-1.618.2-3.237v-1.517C22 9.62 21.8 8 21.8 8zM9.935 14.595v-5.62l5.403 2.82-5.403 2.8z" />
	</SVG>
);

registerBlockType(name, {
	title: __("Youtube動画", "cwc-blocks"),
	icon: yticon,
	description: __("YouTube動画を埋め込む。", "cwc-blocks"),
	edit: MediaEdit,
	save: MediaSave,
});
