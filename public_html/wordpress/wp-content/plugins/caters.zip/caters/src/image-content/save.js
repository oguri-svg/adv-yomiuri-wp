import { useBlockProps, RichText } from "@wordpress/block-editor";
import clsx from "clsx";

export default function save({ attributes }) {
	const { data } = attributes;
	// if (!src) return null;

	return (
		<div {...useBlockProps.save()}>
			{data?.map(({ src, alt, caption, captionAlign, content }, index) => (
				<div className="col">
					{src && (
						<>
							<figure class="photo">
								<img src={src} alt={alt} loading="lazy" decoding="async" />
							</figure>
							{caption && (
								<span className={`image-caption caption-align-${captionAlign}`}>
									{caption}
								</span>
							)}
							<div className="content">
								<RichText.Content value={content} />
							</div>
						</>
					)}
				</div>
			))}
		</div>
	);
}
